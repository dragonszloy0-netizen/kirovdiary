plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.kirov.schoolmod"
    compileSdk = 34
    defaultConfig {
        applicationId = "ru.kirov.schoolmod.mod"   // отдельный package, не конфликтует с оригиналом
        minSdk = 26
        targetSdk = 34
        // На GitHub номер растёт с каждой сборкой, поэтому новый APK ставится поверх старого.
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "2.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    // Один постоянный ключ для всех сборок: иначе Android не даёт обновить приложение
    // поверх предыдущей версии. Держите репозиторий приватным (ключ лежит в app/diary.jks).
    signingConfigs {
        create("diary") {
            storeFile = file("diary.jks")
            storePassword = "diary2026"
            keyAlias = "diary"
            keyPassword = "diary2026"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("diary") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("diary") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
