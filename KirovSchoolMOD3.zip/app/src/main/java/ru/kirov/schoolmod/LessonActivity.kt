package ru.kirov.schoolmod

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Экран урока: предмет, время, учитель, тема и домашнее задание. Открывается из «Дневника». */
class LessonActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = C.DARK_BLUE
        val day = intent.getIntExtra("day", 0)
        val idx = intent.getIntExtra("idx", 0)
        val lesson = ScheduleStore.load(this).getOrNull(day)?.getOrNull(idx)
        if (lesson == null) { finish(); return }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(header("Дневник"), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        col.addView(TextView(this).apply {
            text = "←"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(C.BLUE)
            background = roundBg(C.LIGHT, 2)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(50), dp(50)))

        fun blue(t: String) = TextView(this).apply {
            text = t; textSize = 26f; setTextColor(C.BLUE)
            setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(10), 0, dp(4))
        }
        col.addView(blue(lesson.subject.ifBlank { "Без названия" }),
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })
        col.addView(blue("${idx + 1} урок\n${lesson.start} – ${lesson.end}"))
        if (lesson.room.isNotBlank()) col.addView(blue("Кабинет ${lesson.room}"))
        if (lesson.teacher.isNotBlank()) col.addView(blue(lesson.teacher))

        fun bold(t: String, top: Int) = TextView(this).apply {
            text = t; textSize = 21f; setTextColor(Color.BLACK)
            setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(top), 0, dp(6))
        }
        fun plain(t: String) = TextView(this).apply {
            text = t; textSize = 21f; setTextColor(0xFF222222.toInt())
        }

        if (lesson.topic.isNotBlank()) col.addView(bold("Тема урока: ${lesson.topic.trim()}", 24))
        if (lesson.hwToday.isNotBlank()) {
            col.addView(bold("Домашнее задание на сегодня:", 18))
            col.addView(plain(lesson.hwToday.trim()))
        }
        if (lesson.hwNext.isNotBlank()) {
            col.addView(bold("Домашнее задание на следующий урок:", 18))
            col.addView(plain(lesson.hwNext.trim()))
        }
        if (lesson.topic.isBlank() && lesson.hwToday.isBlank() && lesson.hwNext.isBlank()) {
            col.addView(TextView(this).apply {
                text = "Тема и домашнее задание пока не добавлены"; textSize = 16f
                setTextColor(0xFF777777.toInt()); setPadding(0, dp(24), 0, 0)
            })
        }
        root.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
