package ru.kirov.schoolmod

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {
    private val monthNames = listOf("Январь","Февраль","Март","Апрель","Май","Июнь","Июль",
        "Август","Сентябрь","Октябрь","Ноябрь","Декабрь")
    private val dayNames = listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС")
    private val tabNames = listOf("Основное","Дневник","Успеваемость","Профиль")
    private val tabIcons = listOf(R.drawable.ic_nav_home, R.drawable.ic_nav_book,
        R.drawable.ic_nav_chart, R.drawable.ic_nav_person)

    private var weekOffset = 0
    private var selectedDay = 0
    private var data = ScheduleStore.defaults()
    private var tab = 0

    private lateinit var monthLabel: TextView
    private lateinit var strip: LinearLayout
    private lateinit var lessons: LinearLayout
    private lateinit var homeView: View
    private lateinit var diaryView: View
    private lateinit var gradesView: View
    private lateinit var grades: GradesScreen
    private lateinit var bottom: LinearLayout

    // Секретный вход: 7 быстрых нажатий на заголовок (интервал < 800 мс)
    private var taps = 0
    private var lastTap = 0L

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = C.DARK_BLUE
        val cal = Calendar.getInstance()
        selectedDay = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        val title = header("Образование Кировской области")
        title.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            taps = if (now - lastTap < 800) taps + 1 else 1
            lastTap = now
            if (taps >= 7) { taps = 0; startActivity(Intent(this, EditorActivity::class.java)) }
        }
        root.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        grades = GradesScreen(this)
        homeView = buildHome(); diaryView = buildDiary(); gradesView = grades.view
        val content = FrameLayout(this)
        content.addView(homeView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        content.addView(diaryView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        content.addView(gradesView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        bottom = LinearLayout(this).apply { setBackgroundColor(Color.WHITE); weightSum = 4f }
        for (i in 0 until 4) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setOnClickListener {
                    if (i == 3) Toast.makeText(this@MainActivity, "Недоступно в MOD", Toast.LENGTH_SHORT).show()
                    else show(i)
                }
            }
            item.addView(ImageView(this).apply { setImageResource(tabIcons[i]) },
                LinearLayout.LayoutParams(dp(30), dp(30)))
            item.addView(TextView(this).apply {
                text = tabNames[i]; gravity = Gravity.CENTER; textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
            })
            bottom.addView(item, LinearLayout.LayoutParams(0, dp(66), 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        setContentView(root)
        show(0)   // при запуске открывается «Основное»
    }

    override fun onResume() {
        super.onResume()
        data = ScheduleStore.load(this)
        renderDiary()
        grades.refresh()
    }

    private fun show(t: Int) {
        tab = t
        homeView.visibility = if (t == 0) View.VISIBLE else View.GONE
        diaryView.visibility = if (t == 1) View.VISIBLE else View.GONE
        gradesView.visibility = if (t == 2) View.VISIBLE else View.GONE
        for (i in 0 until 4) {
            val item = bottom.getChildAt(i) as LinearLayout
            (item.getChildAt(0) as ImageView).setColorFilter(if (i == t) C.BLUE else 0xFF444444.toInt())
            (item.getChildAt(1) as TextView).apply {
                setTextColor(C.BLUE)
                visibility = if (i == t) View.VISIBLE else View.GONE   // подпись только у выбранной вкладки
            }
        }
    }

    // ---------- Основное ----------
    private fun tile(icon: String, label: String, onClick: () -> Unit): LinearLayout {
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(TextView(ctx).apply {
                text = icon; textSize = 34f; gravity = Gravity.CENTER
                background = roundBg(C.LIGHT, 60)
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(96))
            })
            addView(TextView(ctx).apply {
                text = label; textSize = 17f; gravity = Gravity.CENTER
                setTextColor(C.BLUE); setPadding(0, dp(8), 0, 0)
            })
            setOnClickListener { onClick() }
        }
    }

    private fun buildHome(): View {
        val na = { Toast.makeText(this, "Недоступно в MOD", Toast.LENGTH_SHORT).show() }
        val items = listOf(
            Triple("📋", "Дневник") { show(1) },
            Triple("📅", "Успеваемость") { show(2) },
            Triple("👤", "Профиль") { na() },
            Triple("📰", "Новости") { na() },
            Triple("🏛", "Школьный музей") { na() },
            Triple("🦉", "Цифровой помощник") { na() }
        )
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)) }
        for (r in 0 until 3) {
            val row = LinearLayout(this).apply { weightSum = 2f }
            for (c in 0 until 2) {
                val it = items[r * 2 + c]
                row.addView(tile(it.first, it.second, it.third), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            }
            col.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(36) })
        }
        return ScrollView(this).apply { addView(col) }
    }

    // ---------- Дневник ----------
    private fun arrow(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 24f; gravity = Gravity.CENTER; setTextColor(C.BLUE)
        background = roundBg(C.LIGHT, 40)
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(2), 0, dp(2), 0) }
        setOnClickListener { onClick() }
    }

    private fun buildDiary(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        monthLabel = TextView(this).apply {
            textSize = 24f; setTextColor(0xFF222222.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(12))
        }
        col.addView(monthLabel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        val navRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), dp(8)) }
        navRow.addView(arrow("←") { weekOffset--; renderDiary() })
        strip = LinearLayout(this).apply { weightSum = 7f }
        navRow.addView(strip, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        navRow.addView(arrow("→") { weekOffset++; renderDiary() })
        col.addView(navRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        lessons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16)) }
        col.addView(ScrollView(this).apply { addView(lessons) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        return col
    }

    private fun renderDiary() {
        val monday = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            add(Calendar.WEEK_OF_YEAR, weekOffset)
        }
        monthLabel.text = "${monthNames[monday.get(Calendar.MONTH)]} ${monday.get(Calendar.YEAR)}"
        strip.removeAllViews()
        for (i in 0 until 7) {
            val c = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, i) }
            val colv = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(6))
                background = if (i == selectedDay) roundBg(Color.WHITE, 4, C.BLUE) else roundBg(Color.WHITE, 4)
                setOnClickListener { selectedDay = i; renderDiary() }
            }
            colv.addView(TextView(this).apply { text = dayNames[i]; textSize = 12f
                setTextColor(if (i == 6) C.RED else Color.BLACK) })
            colv.addView(TextView(this).apply { text = c.get(Calendar.DAY_OF_MONTH).toString(); textSize = 18f
                setTypeface(typeface, Typeface.BOLD); setTextColor(if (i == 6) C.RED else Color.BLACK) })
            strip.addView(colv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(1), 0, dp(1), 0) })
        }
        lessons.removeAllViews()
        val day = data[selectedDay]
        if (day.isEmpty()) {
            lessons.addView(TextView(this).apply { text = "Нет уроков"; gravity = Gravity.CENTER
                textSize = 16f; setTextColor(0xFF777777.toInt()); setPadding(0, dp(40), 0, 0) })
        }
        day.forEachIndexed { idx, l ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = roundBg(Color.WHITE, 12)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, LessonActivity::class.java)
                        .putExtra("day", selectedDay).putExtra("idx", idx))
                }
            }
            card.addView(TextView(this).apply { text = "${ScheduleStore.lessonNumber(l, idx)}. ${l.subject}"; textSize = 18f
                setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD) })
            val info = listOfNotNull("${l.start} – ${l.end}", if (l.room.isNotBlank()) "каб. ${l.room}" else null)
                .joinToString("  •  ")
            card.addView(TextView(this).apply { text = info; textSize = 14f; setTextColor(C.BLUE) })
            if (l.teacher.isNotBlank()) {
                card.addView(TextView(this).apply { text = l.teacher; textSize = 14f; setTextColor(0xFF555555.toInt()) })
            }
            if (l.hwToday.isNotBlank() || l.hwNext.isNotBlank()) {
                card.addView(TextView(this).apply { text = "Есть домашнее задание"; textSize = 13f
                    setTextColor(0xFF2E8B57.toInt()); setPadding(0, dp(4), 0, 0) })
            }
            lessons.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(0, 0, 0, dp(10)) })
        }
    }
}
