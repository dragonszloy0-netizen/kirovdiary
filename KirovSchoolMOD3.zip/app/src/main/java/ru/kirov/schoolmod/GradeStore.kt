package ru.kirov.schoolmod

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.util.Locale

/** Текущая оценка. quarter: 1..4. */
data class Grade(val id: Long, val subject: String, val epochDay: Long, val value: Int, val quarter: Int)

/** Итоговая оценка. period: 1..4 — четверти, 5 — год. */
data class FinalGrade(val subject: String, val period: Int, val value: Int)

class GradeData(
    val grades: MutableList<Grade> = mutableListOf(),
    val finals: MutableList<FinalGrade> = mutableListOf(),
    /** Свой список предметов для оценок (не зависит от расписания). Порядок сохраняется. */
    val subjects: MutableList<String> = GradeStore.DEFAULT_SUBJECTS.toMutableList()
)

/** Локальное хранилище оценок (SharedPreferences). Сохраняется после перезапуска приложения. */
object GradeStore {
    private const val PREFS = "grades_prefs"
    private const val KEY = "grades_json"

    /** Предметы по умолчанию. Дальше список правится в редакторе оценок. */
    val DEFAULT_SUBJECTS = listOf(
        "Алгебра", "Геометрия", "Русский язык", "Литература", "Английский язык",
        "География", "Физика", "Химия", "Биология", "История", "Обществознание",
        "Информатика", "Физкультура", "ОБЗР", "Труд (технология)",
        "Функциональная грамотность", "ВиС", "ОПД", "Профминимум"
    )
    private const val SUBJECTS_VERSION = 2   // 2 = предметы 9а

    fun load(ctx: Context): GradeData {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, null) ?: return GradeData()
        return try {
            val root = JSONObject(raw)
            val g = root.optJSONArray("g") ?: JSONArray()
            val f = root.optJSONArray("f") ?: JSONArray()
            val grades = MutableList(g.length()) { i ->
                val o = g.getJSONObject(i)
                Grade(o.getLong("id"), o.getString("s"), o.getLong("d"), o.getInt("v"), o.getInt("q"))
            }
            val finals = MutableList(f.length()) { i ->
                val o = f.getJSONObject(i)
                FinalGrade(o.getString("s"), o.getInt("p"), o.getInt("v"))
            }
            val sj = root.optJSONArray("subs")
            val subjects: MutableList<String> = if (sj != null && root.optInt("sv", 1) >= SUBJECTS_VERSION) {
                MutableList(sj.length()) { i -> sj.getString(i) }
            } else {
                // Первое обновление: стандартный список + предметы, у которых уже есть оценки.
                val l = DEFAULT_SUBJECTS.toMutableList()
                (grades.map { it.subject } + finals.map { it.subject }).forEach { n ->
                    val t = n.trim()
                    if (t.isNotEmpty() && l.none { it.equals(t, ignoreCase = true) }) l.add(t)
                }
                l
            }
            GradeData(grades, finals, subjects)
        } catch (e: Exception) {
            // Повреждённые данные не затираем молча: копия остаётся в соседнем ключе.
            prefs.edit().putString("grades_json_broken", raw).commit()
            GradeData()
        }
    }

    fun save(ctx: Context, data: GradeData) {
        val g = JSONArray()
        for (x in data.grades) {
            g.put(
                JSONObject().put("id", x.id).put("s", x.subject).put("d", x.epochDay)
                    .put("v", x.value).put("q", x.quarter)
            )
        }
        val f = JSONArray()
        for (x in data.finals) {
            f.put(JSONObject().put("s", x.subject).put("p", x.period).put("v", x.value))
        }
        val subs = JSONArray()
        for (x in data.subjects) subs.put(x)
        val root = JSONObject().put("g", g).put("f", f).put("subs", subs).put("sv", SUBJECTS_VERSION)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, root.toString()).commit()
    }

    fun nextId(data: GradeData): Long = (data.grades.maxOfOrNull { it.id } ?: 0L) + 1L

    fun average(values: List<Int>): Double? =
        if (values.isEmpty()) null else values.sum().toDouble() / values.size

    /** 3.75 -> "3.75", 4.5 -> "4.5", 4.0 -> "4". */
    fun format(avg: Double): String =
        BigDecimal.valueOf(avg).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

    /** Четверть по дате: сен–окт = 1, ноя–дек = 2, янв–мар = 3, остальное = 4. */
    fun quarterOf(date: LocalDate): Int = when (date.monthValue) {
        9, 10 -> 1
        11, 12 -> 2
        1, 2, 3 -> 3
        else -> 4
    }

    fun shortDate(epochDay: Long): String {
        val d = LocalDate.ofEpochDay(epochDay)
        return String.format(Locale.ROOT, "%02d.%02d", d.dayOfMonth, d.monthValue)
    }

    fun fullDate(date: LocalDate): String =
        String.format(Locale.ROOT, "%02d.%02d.%d", date.dayOfMonth, date.monthValue, date.year)
}
