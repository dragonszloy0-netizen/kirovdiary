package ru.kirov.schoolmod

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate

/** Цвет оценки или среднего балла: 5 — зелёный, 4 — салатовый, 3 — жёлтый, 2 — оранжевый, 1 — красный. */
fun gradeColor(v: Double): Int = when {
    v >= 4.75 -> 0xFF5DB82E.toInt()
    v >= 4.0 -> 0xFF8CC63F.toInt()
    v >= 3.0 -> 0xFFF5B800.toInt()
    v >= 2.0 -> 0xFFF57C00.toInt()
    else -> 0xFFE53935.toInt()
}

private val QUARTER_NAMES = listOf("Первая\nчетверть", "Вторая\nчетверть", "Третья\nчетверть", "Четвёртая\nчетверть")
private val PERIOD_NAMES = listOf("1 четверть", "2 четверть", "3 четверть", "4 четверть", "Год")
private const val GRAY_BG = 0xFFE9ECF3.toInt()

/**
 * Экран «Успеваемость»: «Текущая» (оценки по датам внутри четверти) и «Итоговая»
 * (оценки за четверти и год). Оценки можно добавлять, менять и удалять, всё сохраняется.
 * Список предметов берётся из расписания, плюс предметы, у которых уже есть оценки.
 */
class GradesScreen(private val act: Activity, private val editable: Boolean = false) {
    private var data = GradeStore.load(act)
    private var mode = 0
    private var quarter = GradeStore.quarterOf(LocalDate.now())

    private val modeRow = LinearLayout(act).apply {
        gravity = Gravity.CENTER
        setPadding(0, act.dp(16), 0, act.dp(4))
    }
    private val quarterRow = LinearLayout(act).apply {
        setPadding(act.dp(12), act.dp(8), act.dp(12), act.dp(8))
    }
    private val quarterScroll = HorizontalScrollView(act).apply {
        isHorizontalScrollBarEnabled = false
        addView(quarterRow)
    }
    private val list = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(24))
    }

    val view: View = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        addView(modeRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        addView(quarterScroll, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        addView(ScrollView(act).apply { addView(list) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
    }

    init {
        render()
    }

    /** Вызывается при каждом возврате на экран: подтягивает свежие данные. */
    fun refresh() {
        data = GradeStore.load(act)
        render()
    }

    private fun same(a: String, b: String) = a.trim().equals(b.trim(), ignoreCase = true)

    private fun allSubjects(): List<String> = data.subjects.toList()

    // ---------- Отрисовка ----------

    private fun pill(text: String, selected: Boolean, hPad: Int = 22, onClick: () -> Unit) = TextView(act).apply {
        this.text = text
        textSize = 16f
        gravity = Gravity.CENTER
        maxLines = 2
        setTextColor(if (selected) Color.WHITE else C.BLUE)
        background = act.roundBg(if (selected) C.BLUE else GRAY_BG, 50)
        setPadding(act.dp(hPad), act.dp(10), act.dp(hPad), act.dp(10))
        setOnClickListener { onClick() }
    }

    private fun render() {
        modeRow.removeAllViews()
        modeRow.addView(pill("Текущая", mode == 0) { mode = 0; render() })
        modeRow.addView(
            pill("Итоговая", mode == 1) { mode = 1; render() },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = act.dp(16) }
        )

        quarterScroll.visibility = if (mode == 0) View.VISIBLE else View.GONE
        quarterRow.removeAllViews()
        QUARTER_NAMES.forEachIndexed { i, name ->
            quarterRow.addView(
                pill(name, quarter == i + 1, 16) { quarter = i + 1; render() },
                LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = act.dp(8) }
            )
        }

        list.removeAllViews()
        val subjects = allSubjects()
        if (subjects.isEmpty()) {
            list.addView(TextView(act).apply {
                text = "Предметов пока нет."
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(0xFF777777.toInt())
                setPadding(0, act.dp(40), 0, 0)
            })
        }
        for (s in subjects) {
            if (mode == 0) addCurrent(s) else addFinal(s)
        }
        if (editable) {
            list.addView(
                act.button("+ Добавить предмет", C.BLUE) { subjectDialog(null) },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = act.dp(8) }
            )
        }
    }

    private fun tileParams() = LinearLayout.LayoutParams(act.dp(50), act.dp(62)).apply {
        rightMargin = act.dp(4)
        topMargin = act.dp(2)
        bottomMargin = act.dp(4)
    }

    private fun addCurrent(subject: String) {
        val grades = data.grades
            .filter { same(it.subject, subject) && it.quarter == quarter }
            .sortedWith(compareBy<Grade>({ it.epochDay }, { it.id }))

        list.addView(titleRow(subject, 24f))

        val row = LinearLayout(act)
        for (g in grades) row.addView(tile(g), tileParams())
        if (editable) row.addView(addTile(subject), tileParams())
        list.addView(
            HorizontalScrollView(act).apply {
                isHorizontalScrollBarEnabled = false
                addView(row)
            },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = act.dp(10) }
        )

        val avg = GradeStore.average(grades.map { it.value })
        val avgRow = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, act.dp(10), 0, act.dp(22))
        }
        avgRow.addView(TextView(act).apply {
            text = "Средний балл:  "
            textSize = 18f
            setTextColor(0xFF222222.toInt())
        })
        avgRow.addView(TextView(act).apply {
            text = if (avg == null) "—" else GradeStore.format(avg)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (avg == null) 0xFF777777.toInt() else gradeColor(avg))
        })
        list.addView(avgRow)
    }

    private fun tile(g: Grade): View = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = act.roundBg(Color.WHITE, 4)
        elevation = act.dp(1).toFloat()
        setPadding(act.dp(5), act.dp(4), act.dp(5), act.dp(4))
        addView(TextView(act).apply {
            text = GradeStore.shortDate(g.epochDay)
            textSize = 14f
            setTextColor(0xFF222222.toInt())
        })
        addView(TextView(act).apply {
            text = g.value.toString()
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(gradeColor(g.value.toDouble()))
        })
        if (editable) setOnClickListener { gradeDialog(g.subject, g) }
    }

    private fun addTile(subject: String): View = TextView(act).apply {
        text = "+"
        textSize = 30f
        gravity = Gravity.CENTER
        setTextColor(C.BLUE)
        background = act.roundBg(GRAY_BG, 4)
        setOnClickListener { gradeDialog(subject, null) }
    }

    private fun addFinal(subject: String) {
        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = act.roundBg(Color.WHITE, 12)
            elevation = act.dp(1).toFloat()
            setPadding(act.dp(12), act.dp(10), act.dp(12), act.dp(10))
        }
        card.addView(titleRow(subject, 18f))
        val row = LinearLayout(act).apply {
            weightSum = 5f
            setPadding(0, act.dp(8), 0, 0)
        }
        for (p in 1..5) {
            val finalValue = data.finals
                .firstOrNull { same(it.subject, subject) && it.period == p }?.value
            val values = data.grades
                .filter { same(it.subject, subject) && (p == 5 || it.quarter == p) }
                .map { it.value }
            val avg = GradeStore.average(values)

            val cell = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, act.dp(6), 0, act.dp(6))
                if (editable) setOnClickListener { finalDialog(subject, p) }
            }
            cell.addView(TextView(act).apply {
                text = if (p == 5) "Год" else "$p четв."
                textSize = 12f
                setTextColor(0xFF666666.toInt())
            })
            cell.addView(TextView(act).apply {
                text = finalValue?.toString() ?: "—"
                textSize = 28f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (finalValue != null) gradeColor(finalValue.toDouble()) else 0xFF999999.toInt())
            })
            cell.addView(TextView(act).apply {
                text = if (avg != null) "ср. ${GradeStore.format(avg)}" else " "
                textSize = 11f
                setTextColor(0xFF666666.toInt())
            })
            row.addView(cell, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        card.addView(row)
        list.addView(
            card,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = act.dp(10) }
        )
    }

    private fun titleRow(subject: String, size: Float): View {
        val row = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(act).apply {
            text = subject
            textSize = size
            setTextColor(Color.BLACK)
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        if (editable) {
            row.addView(TextView(act).apply {
                text = "Изменить"
                textSize = 14f
                setTextColor(C.BLUE)
                setPadding(act.dp(10), act.dp(6), act.dp(4), act.dp(6))
                setOnClickListener { subjectDialog(subject) }
            })
        }
        return row
    }

    // ---------- Диалоги ----------
    /** old == null — новый предмет, иначе переименование или удаление. */
    private fun subjectDialog(old: String?) {
        val input = EditText(act).apply {
            setText(old ?: "")
            hint = "Название предмета"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
        }
        val box = LinearLayout(act).apply {
            setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
            addView(input, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        val builder = AlertDialog.Builder(act)
            .setTitle(if (old == null) "Новый предмет" else "Предмет")
            .setView(box)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
        if (old != null) builder.setNeutralButton("Удалить", null)
        val dialog = builder.create()
        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val name = input.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(act, "Введите название", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (data.subjects.any { it.equals(name, ignoreCase = true) && (old == null || !same(it, old)) }) {
                Toast.makeText(act, "Такой предмет уже есть", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (old == null) data.subjects.add(name) else renameSubject(old, name)
            GradeStore.save(act, data)
            dialog.dismiss()
            render()
        }
        if (old != null) {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                AlertDialog.Builder(act)
                    .setTitle("Удалить «$old»?")
                    .setMessage("Вместе с предметом удалятся все его оценки.")
                    .setPositiveButton("Удалить") { _, _ ->
                        data.subjects.removeAll { same(it, old) }
                        data.grades.removeAll { same(it.subject, old) }
                        data.finals.removeAll { same(it.subject, old) }
                        GradeStore.save(act, data)
                        dialog.dismiss()
                        render()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
        }
    }

    private fun renameSubject(old: String, name: String) {
        for (i in data.subjects.indices) if (same(data.subjects[i], old)) data.subjects[i] = name
        for (i in data.grades.indices) {
            val g = data.grades[i]
            if (same(g.subject, old)) data.grades[i] = g.copy(subject = name)
        }
        for (i in data.finals.indices) {
            val g = data.finals[i]
            if (same(g.subject, old)) data.finals[i] = g.copy(subject = name)
        }
    }


    /** Пять круглых кнопок 1–5. */
    private fun gradePicker(initial: Int?, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(act)
        val circles = ArrayList<TextView>()
        fun paint(sel: Int?) {
            circles.forEachIndexed { i, tv ->
                val c = gradeColor((i + 1).toDouble())
                val on = sel == i + 1
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (on) c else ((c and 0x00FFFFFF) or 0x30000000))
                }
                tv.setTextColor(if (on) Color.WHITE else c)
            }
        }
        for (v in 1..5) {
            val tv = TextView(act).apply {
                text = v.toString()
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setOnClickListener { paint(v); onPick(v) }
            }
            circles.add(tv)
            val cell = FrameLayout(act)
            cell.addView(tv, FrameLayout.LayoutParams(act.dp(42), act.dp(42), Gravity.CENTER))
            row.addView(cell, LinearLayout.LayoutParams(0, act.dp(48), 1f))
        }
        paint(initial)
        return row
    }

    private fun gradeDialog(subject: String, existing: Grade?) {
        var date = existing?.let { LocalDate.ofEpochDay(it.epochDay) } ?: LocalDate.now()
        var value: Int? = existing?.value
        var q = existing?.quarter ?: quarter
        var qTouched = existing != null

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        }
        box.addView(TextView(act).apply {
            text = subject
            textSize = 18f
            setTextColor(Color.BLACK)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, act.dp(12))
        })

        val dateBtn = TextView(act).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(C.BLUE)
            background = act.roundBg(C.LIGHT, 10)
            setPadding(act.dp(12), act.dp(12), act.dp(12), act.dp(12))
        }
        val qViews = ArrayList<TextView>()

        fun updateDate() {
            dateBtn.text = "Дата: ${GradeStore.fullDate(date)}"
        }

        fun paintQ() {
            qViews.forEachIndexed { i, tv ->
                val on = q == i + 1
                tv.setTextColor(if (on) Color.WHITE else C.BLUE)
                tv.background = act.roundBg(if (on) C.BLUE else C.LIGHT, 50)
            }
        }

        dateBtn.setOnClickListener {
            DatePickerDialog(
                act,
                { _, y, m, d ->
                    date = LocalDate.of(y, m + 1, d)
                    if (!qTouched) q = GradeStore.quarterOf(date)
                    updateDate()
                    paintQ()
                },
                date.year, date.monthValue - 1, date.dayOfMonth
            ).show()
        }
        box.addView(dateBtn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        box.addView(
            gradePicker(value) { value = it },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = act.dp(16) }
        )

        val qRow = LinearLayout(act).apply { weightSum = 4f }
        for (i in 1..4) {
            val tv = TextView(act).apply {
                text = "$i четв."
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, act.dp(8), 0, act.dp(8))
                setOnClickListener { q = i; qTouched = true; paintQ() }
            }
            qViews.add(tv)
            qRow.addView(tv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                setMargins(act.dp(2), 0, act.dp(2), 0)
            })
        }
        box.addView(qRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            topMargin = act.dp(16)
        })
        updateDate()
        paintQ()

        val builder = AlertDialog.Builder(act)
            .setTitle(if (existing == null) "Новая оценка" else "Оценка")
            .setView(box)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
        if (existing != null) builder.setNeutralButton("Удалить", null)
        val dialog = builder.create()
        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val v = value
            if (v == null) {
                Toast.makeText(act, "Выберите оценку", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (existing == null) {
                data.grades.add(Grade(GradeStore.nextId(data), subject, date.toEpochDay(), v, q))
            } else {
                val idx = data.grades.indexOfFirst { it.id == existing.id }
                if (idx >= 0) data.grades[idx] = Grade(existing.id, subject, date.toEpochDay(), v, q)
            }
            GradeStore.save(act, data)
            quarter = q
            dialog.dismiss()
            render()
        }
        if (existing != null) {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                data.grades.removeAll { it.id == existing.id }
                GradeStore.save(act, data)
                dialog.dismiss()
                render()
            }
        }
    }

    private fun setFinal(subject: String, period: Int, value: Int?) {
        data.finals.removeAll { same(it.subject, subject) && it.period == period }
        if (value != null) data.finals.add(FinalGrade(subject, period, value))
        GradeStore.save(act, data)
    }

    private fun finalDialog(subject: String, period: Int) {
        val current = data.finals
            .firstOrNull { same(it.subject, subject) && it.period == period }?.value
        var dialog: AlertDialog? = null

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        }
        box.addView(TextView(act).apply {
            text = "$subject — ${PERIOD_NAMES[period - 1]}"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, act.dp(16))
        })
        box.addView(gradePicker(current) { v ->
            setFinal(subject, period, v)
            dialog?.dismiss()
            render()
        })

        val builder = AlertDialog.Builder(act)
            .setTitle("Итоговая оценка")
            .setView(box)
            .setNegativeButton("Отмена", null)
        if (current != null) {
            builder.setNeutralButton("Очистить") { _, _ ->
                setFinal(subject, period, null)
                render()
            }
        }
        val created = builder.create()
        dialog = created
        created.show()
    }
}
