package ru.kirov.schoolmod

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Lesson(
    var subject: String, var room: String, var teacher: String,
    var start: String, var end: String
)

/** Локальное хранилище расписания. Сервер не затрагивается. Индекс дня: 0 = ПН ... 6 = ВС. */
object ScheduleStore {
    private const val PREFS = "schedule_prefs"
    private const val KEY = "schedule_json"

    fun defaults(): MutableList<MutableList<Lesson>> = MutableList(7) { d ->
        if (d < 5) mutableListOf(
            Lesson("Математика", "204", "Иванова И.И.", "08:30", "09:15"),
            Lesson("Русский язык", "112", "Петрова А.А.", "09:25", "10:10"),
            Lesson("Физкультура", "Спортзал", "Сидоров П.П.", "10:30", "11:15")
        ) else mutableListOf()
    }

    fun load(ctx: Context): MutableList<MutableList<Lesson>> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            MutableList(7) { d ->
                val day = arr.optJSONArray(d) ?: JSONArray()
                MutableList(day.length()) { i ->
                    val o = day.getJSONObject(i)
                    Lesson(o.optString("s"), o.optString("r"), o.optString("t"),
                        o.optString("a"), o.optString("b"))
                }
            }
        } catch (e: Exception) { defaults() }
    }

    fun save(ctx: Context, data: List<List<Lesson>>) {
        val arr = JSONArray()
        for (day in data) {
            val da = JSONArray()
            for (l in day) da.put(JSONObject()
                .put("s", l.subject).put("r", l.room).put("t", l.teacher)
                .put("a", l.start).put("b", l.end))
            arr.put(da)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, arr.toString()).apply()
    }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
