package ru.kirov.schoolmod

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Lesson(
    var subject: String, var room: String, var teacher: String,
    var start: String, var end: String,
    var topic: String = "",      // тема урока
    var hwToday: String = "",    // домашнее задание на сегодня
    var hwNext: String = ""      // домашнее задание на следующий урок
)

/** Локальное хранилище расписания. Сервер не затрагивается. Индекс дня: 0 = ПН ... 6 = ВС. */
object ScheduleStore {
    private const val PREFS = "schedule_prefs"
    private const val KEY = "schedule_json"
    private const val VER_KEY = "schedule_ver"
    private const val VERSION = 2   // 2 = расписание 9а

    /** Звонки: номер урока = позиция в списке + 1. */
    val BELLS = listOf(
        "08:00" to "08:40", "08:50" to "09:30", "09:50" to "10:30",
        "10:50" to "11:30", "11:40" to "12:20", "12:30" to "13:10",
        "13:30" to "14:10", "14:20" to "15:00", "15:20" to "16:00"
    )

    /** Номер урока по времени начала (так четверг без 1-го урока начинается со 2-го). */
    fun lessonNumber(l: Lesson, idx: Int): Int {
        val i = BELLS.indexOfFirst { it.first == l.start.trim() }
        return if (i >= 0) i + 1 else idx + 1
    }

    /** Звонок для нового урока в конце дня. */
    fun nextBell(day: List<Lesson>): Pair<String, String> {
        val last = day.lastOrNull() ?: return BELLS[0]
        return BELLS.getOrNull(lessonNumber(last, day.size - 1)) ?: Pair("", "")
    }

    private fun les(n: Int, subject: String, room: String = "") =
        Lesson(subject, room, "", BELLS[n - 1].first, BELLS[n - 1].second)

    /** Расписание 9а класса. Учителей в исходной таблице нет — заполняются в редакторе. */
    fun defaults(): MutableList<MutableList<Lesson>> = mutableListOf(
        // ПН
        mutableListOf(
            les(1, "Литература", "7"), les(2, "ОБЗР", "11"), les(3, "Физкультура"),
            les(4, "Разговоры о важном", "24"), les(5, "География"),
            les(6, "Алгебра", "22"), les(7, "Биология", "19")
        ),
        // ВТ
        mutableListOf(
            les(1, "Английский язык", "24"), les(2, "Геометрия", "22"), les(3, "Физика", "18"),
            les(4, "История", "23"), les(5, "Русский язык", "7"), les(6, "Химия", "17"),
            les(7, "Физкультура"), les(8, "Функциональная грамотность", "23")
        ),
        // СР
        mutableListOf(
            les(1, "География", "17"), les(2, "Русский язык", "7"), les(3, "Физика", "18"),
            les(4, "Обществознание", "23"), les(5, "Алгебра", "22"), les(6, "Информатика", "24")
        ),
        // ЧТ (первого урока нет)
        mutableListOf(
            les(2, "История", "23"), les(3, "Литература", "7"), les(4, "Химия", "17"),
            les(5, "Биология", "19"), les(6, "Труд (технология)", "18"),
            les(7, "Английский язык", "24"), les(8, "Алгебра", "22"), les(9, "Профминимум", "24")
        ),
        // ПТ
        mutableListOf(
            les(1, "Английский язык", "24"), les(2, "Геометрия", "22"), les(3, "ОПД", "23"),
            les(4, "Физика", "18"), les(5, "Русский язык", "7"), les(6, "Литература", "7"),
            les(7, "ВиС", "22")
        ),
        mutableListOf(),   // СБ
        mutableListOf()    // ВС
    )

    fun load(ctx: Context): MutableList<MutableList<Lesson>> {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getInt(VER_KEY, 1) < VERSION) return defaults()
        val raw = prefs.getString(KEY, null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            MutableList(7) { d ->
                val day = arr.optJSONArray(d) ?: JSONArray()
                MutableList(day.length()) { i ->
                    val o = day.getJSONObject(i)
                    Lesson(o.optString("s"), o.optString("r"), o.optString("t"),
                        o.optString("a"), o.optString("b"),
                        o.optString("p"), o.optString("h"), o.optString("n"))
                }
            }
        } catch (e: Exception) { defaults() }
    }

    fun save(ctx: Context, data: List<List<Lesson>>) {
        val arr = JSONArray()
        for (day in data) {
            val da = JSONArray()
            for (l in day) da.put(JSONObject()
                .put("s", l.subject).put("r", l.room).put("t", l.teacher)
                .put("a", l.start).put("b", l.end)
                .put("p", l.topic).put("h", l.hwToday).put("n", l.hwNext))
            arr.put(da)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, arr.toString()).putInt(VER_KEY, VERSION).apply()
    }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
