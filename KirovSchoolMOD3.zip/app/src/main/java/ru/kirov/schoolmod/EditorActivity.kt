package ru.kirov.schoolmod

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class EditorActivity : Activity() {
    private val dayNames = listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС")
    private lateinit var data: MutableList<MutableList<Lesson>>
    private var day = 0

    private class Row(val l: Lesson, val subj: EditText, val room: EditText,
                      val teacher: EditText, val start: EditText, val end: EditText,
                      val topic: EditText, val hwToday: EditText, val hwNext: EditText)
    private val rows = mutableListOf<Row>()

    private lateinit var tabs: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var modeBar: LinearLayout
    private lateinit var scheduleBox: LinearLayout
    private lateinit var grades: GradesScreen
    private var mode = 0   // 0 = расписание, 1 = оценки
    private lateinit var list: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = C.DARK_BLUE
        data = ScheduleStore.load(this)
        grades = GradesScreen(this, true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        titleView = header("Редактор расписания")
        root.addView(titleView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        modeBar = LinearLayout(this).apply { weightSum = 2f; setPadding(dp(8), dp(10), dp(8), 0) }
        root.addView(modeBar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        scheduleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tabs = LinearLayout(this).apply { weightSum = 7f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        scheduleBox.addView(tabs, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), dp(12)) }
        scheduleBox.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(Color.WHITE) }
        bar.addView(button("+ Добавить урок", C.BLUE) {
            collect(); val b = ScheduleStore.nextBell(data[day]); data[day].add(Lesson("", "", "", b.first, b.second)); render()
        })
        bar.addView(spacer(8))
        val two = LinearLayout(this).apply { weightSum = 2f }
        two.addView(button("Сохранить", 0xFF2E8B57.toInt()) {
            collect(); ScheduleStore.save(this, data)
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { rightMargin = dp(4) })
        two.addView(button("Вернуть оригинал", C.RED) {
            AlertDialog.Builder(this).setTitle("Вернуть оригинальное расписание?")
                .setMessage("Все ваши изменения будут удалены.")
                .setPositiveButton("Да") { _, _ ->
                    ScheduleStore.reset(this); data = ScheduleStore.load(this); render()
                    Toast.makeText(this, "Расписание сброшено", Toast.LENGTH_SHORT).show()
                }.setNegativeButton("Отмена", null).show()
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4) })
        bar.addView(two)
        scheduleBox.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val content = FrameLayout(this)
        content.addView(scheduleBox, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        content.addView(grades.view, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
        renderMode()
        render()
    }

    private fun renderMode() {
        modeBar.removeAllViews()
        val names = listOf("Расписание", "Оценки")
        for (i in 0 until 2) {
            modeBar.addView(TextView(this).apply {
                text = names[i]; gravity = Gravity.CENTER; textSize = 15f
                setPadding(0, dp(10), 0, dp(10))
                setTextColor(if (i == mode) Color.WHITE else Color.BLACK)
                background = roundBg(if (i == mode) C.BLUE else Color.WHITE, 8)
                setOnClickListener { setMode(i) }
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        scheduleBox.visibility = if (mode == 0) View.VISIBLE else View.GONE
        grades.view.visibility = if (mode == 1) View.VISIBLE else View.GONE
        titleView.text = if (mode == 0) "Редактор расписания" else "Редактор оценок"
    }

    private fun setMode(m: Int) {
        if (m == mode) return
        collect(); ScheduleStore.save(this, data)   // чтобы новые предметы сразу появились в оценках
        mode = m
        if (mode == 1) grades.refresh()
        renderMode()
    }

    private fun collect() {
        for (r in rows) {
            r.l.subject = r.subj.text.toString(); r.l.room = r.room.text.toString()
            r.l.teacher = r.teacher.text.toString(); r.l.start = r.start.text.toString()
            r.l.end = r.end.text.toString()
            r.l.topic = r.topic.text.toString(); r.l.hwToday = r.hwToday.text.toString()
            r.l.hwNext = r.hwNext.text.toString()
        }
    }

    private fun field(hint: String, value: String, w: Float = 1f) = EditText(this).apply {
        setHint(hint); setText(value); textSize = 15f; inputType = InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, w)
    }

    /** Многострочное поле (тема, домашнее задание). */
    private fun multi(hint: String, value: String) = EditText(this).apply {
        setHint(hint); setText(value); textSize = 15f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        minLines = 2; gravity = Gravity.TOP or Gravity.START
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
    }

    private fun render() {
        tabs.removeAllViews()
        for (i in 0 until 7) {
            tabs.addView(TextView(this).apply {
                text = dayNames[i]; gravity = Gravity.CENTER; textSize = 15f
                setPadding(0, dp(10), 0, dp(10))
                setTextColor(if (i == day) Color.WHITE else Color.BLACK)
                background = roundBg(if (i == day) C.BLUE else Color.WHITE, 8)
                setOnClickListener { collect(); day = i; render() }
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }

        list.removeAllViews(); rows.clear()
        data[day].forEachIndexed { idx, l ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                background = roundBg(Color.WHITE, 12); setPadding(dp(12), dp(8), dp(12), dp(8)) }
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(TextView(this).apply { text = "Урок ${ScheduleStore.lessonNumber(l, idx)}"; textSize = 16f
                setTextColor(C.BLUE) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            head.addView(TextView(this).apply { text = "Удалить"; setTextColor(C.RED); textSize = 14f
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { collect(); data[day].removeAt(idx); render() } })
            card.addView(head)
            val subj = field("Предмет", l.subject, 1f)
            val teacher = field("Учитель", l.teacher, 1f)
            val room = field("Кабинет", l.room, 1f)
            val start = field("Начало 08:30", l.start, 1f)
            val end = field("Конец 09:15", l.end, 1f)
            card.addView(LinearLayout(this).apply { addView(subj) })
            card.addView(LinearLayout(this).apply { addView(teacher) })
            card.addView(LinearLayout(this).apply { addView(room); addView(start); addView(end) })
            val topic = multi("Тема урока", l.topic)
            val hwToday = multi("Домашнее задание на сегодня", l.hwToday)
            val hwNext = multi("Домашнее задание на следующий урок", l.hwNext)
            card.addView(LinearLayout(this).apply { addView(topic) })
            card.addView(LinearLayout(this).apply { addView(hwToday) })
            card.addView(LinearLayout(this).apply { addView(hwNext) })
            rows.add(Row(l, subj, room, teacher, start, end, topic, hwToday, hwNext))
            list.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(0, 0, 0, dp(10)) })
        }
    }

    // Что бы ни случилось (назад, сворачивание, закрытие) — введённое не пропадает.
    override fun onPause() {
        super.onPause()
        collect()
        ScheduleStore.save(this, data)
    }

    override fun onBackPressed() { collect(); super.onBackPressed() }
}
